-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2024 at 10:55 AM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pzzpps`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `czlonkowie`
--

CREATE TABLE `czlonkowie` (
  `id_czlonka` int(10) UNSIGNED NOT NULL,
  `id_osrodka` int(11) NOT NULL,
  `imie` varchar(20) NOT NULL,
  `nazwisko` varchar(30) NOT NULL,
  `data_urodzenia` date DEFAULT NULL,
  `telefon` int(9) NOT NULL,
  `email` varchar(30) NOT NULL,
  `data_dolaczenia` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `czlonkowie`
--

INSERT INTO `czlonkowie` (`id_czlonka`, `id_osrodka`, `imie`, `nazwisko`, `data_urodzenia`, `telefon`, `email`, `data_dolaczenia`) VALUES
(1, 6, 'Ortensia', 'Coverdale', '1971-10-02', 578274315, 'ocoverdale0@about.com', '2023-10-24'),
(2, 13, 'Gerard', 'Myring', '1962-06-25', 434843509, 'gmyring1@yelp.com', '2022-12-07'),
(4, 8, 'Kai', 'Stiff', '1995-11-21', 590112459, 'kstiff3@angelfire.com', '2023-10-08'),
(6, 8, 'Bard', 'Joliffe', '1982-01-28', 1360099, 'bjoliffe5@diigo.com', '2023-12-26'),
(7, 1, 'Sean', 'Nuss', '1990-08-28', 838370752, 'snuss6@tinyurl.com', '2021-05-24'),
(8, 11, 'Laurent', 'Edney', '1994-10-09', 639010998, 'ledney7@vistaprint.com', '2022-07-22'),
(10, 13, 'Hugh', 'Blyden', '1999-12-08', 207554542, 'hblyden9@vkontakte.ru', '2021-07-28'),
(12, 1, 'Dinah', 'Pyson', '1995-01-11', 117522853, 'dpysonb@php.net', '2024-04-30'),
(13, 12, 'Elden', 'Stark', '1960-02-20', 279096079, 'estarkc@jiathis.com', '2021-06-04'),
(14, 8, 'Renado', 'Guppie', '1960-12-14', 254230328, 'rguppied@google.com.br', '2021-07-16'),
(15, 4, 'Prent', 'Sancto', '1970-05-23', 494757076, 'psanctoe@nsw.gov.au', '2022-02-15'),
(16, 12, 'Paxton', 'Cundict', '1974-05-16', 679989792, 'pcundictf@comcast.net', '2024-07-16'),
(17, 13, 'Doralia', 'Swafford', '1983-05-26', 541413225, 'dswaffordg@cargocollective.com', '2022-09-11'),
(18, 3, 'Gaylene', 'Pirrone', '2000-03-25', 267039599, 'gpirroneh@noaa.gov', '2022-08-10'),
(19, 4, 'Isabeau', 'Klaiser', '1989-09-06', 225751398, 'iklaiseri@yandex.ru', '2022-11-11'),
(20, 5, 'Scott', 'Andrews', '1969-11-03', 918240310, 'sandrewsj@home.pl', '2023-01-01'),
(21, 2, 'Marianna', 'Tunnadine', '1974-12-25', 294431136, 'mtunnadinek@posterous.com', '2022-05-14'),
(22, 1, 'Felipe', 'Grzesiak', '2001-02-26', 571978993, 'fgrzesiakl@jiathis.com', '2021-03-13'),
(23, 3, 'Cindie', 'Bagwell', '1976-07-27', 271655291, 'cbagwellm@loc.gov', '2024-10-25'),
(24, 10, 'Wally', 'Picardo', '1975-11-11', 71891247, 'wpicardon@yolasite.com', '2024-08-10'),
(25, 14, 'Carlie', 'Nottram', '1981-09-24', 269800315, 'cnottramo@sfgate.com', '2024-09-18'),
(26, 7, 'Kellen', 'Frascone', '1989-07-21', 444804890, 'kfrasconep@upenn.edu', '2024-10-16'),
(27, 6, 'Kaia', 'Brecher', '1963-05-12', 648059057, 'kbrecherq@scientificamerican.c', '2024-02-13'),
(28, 7, 'Darrelle', 'Haddon', '1990-10-06', 31776707, 'dhaddonr@prnewswire.com', '2022-02-02'),
(29, 8, 'Bren', 'McGillacoell', '1998-09-09', 961253184, 'bmcgillacoells@yahoo.co.jp', '2021-12-22'),
(30, 11, 'Gwen', 'MacGillreich', '1989-12-22', 308684317, 'gmacgillreicht@booking.com', '2023-09-27'),
(31, 2, 'Wendy', 'Lambkin', '1980-09-28', 574252891, 'wlambkinu@senate.gov', '2024-10-02'),
(32, 14, 'Lauraine', 'Whitebrook', '1981-09-11', 403108510, 'lwhitebrookv@vimeo.com', '2024-08-23'),
(33, 10, 'Phillipe', 'Richten', '1988-07-06', 68879753, 'prichtenw@moonfruit.com', '2022-08-16'),
(34, 2, 'Shanon', 'Flack', '1987-04-12', 99240892, 'sflackx@theatlantic.com', '2023-10-22'),
(35, 1, 'Amelita', 'Berth', '1993-03-16', 603314544, 'aberthy@answers.com', '2023-01-02'),
(36, 11, 'Anstice', 'Speechly', '1985-08-16', 121876299, 'aspeechlyz@oaic.gov.au', '2022-04-20'),
(37, 1, 'Stacia', 'Fenck', '1994-02-05', 811753715, 'sfenck10@constantcontact.com', '2021-09-04'),
(38, 14, 'Raye', 'Fairlie', '1974-06-14', 478763999, 'rfairlie11@nsw.gov.au', '2022-02-15'),
(39, 7, 'Woodie', 'Boaler', '1970-05-20', 826979744, 'wboaler12@php.net', '2022-10-08'),
(40, 2, 'Harold', 'Ionesco', '1990-04-09', 429844394, 'hionesco13@techcrunch.com', '2021-01-23'),
(41, 12, 'Shannon', 'Hanratty', '1988-06-13', 704413311, 'shanratty14@sfgate.com', '2023-08-28'),
(42, 10, 'Austina', 'Kubasek', '1980-05-21', 969480677, 'akubasek15@google.pl', '2022-10-02'),
(43, 11, 'Rollie', 'Feathers', '1999-12-25', 400924990, 'rfeathers16@google.pl', '2023-04-05'),
(44, 10, 'Gaby', 'Bowdery', '1985-04-02', 152633746, 'gbowdery17@blogs.com', '2022-11-09'),
(45, 8, 'Ric', 'Pevie', '1967-03-11', 75758165, 'rpevie18@deliciousdays.com', '2022-06-02'),
(46, 6, 'Celina', 'Stribbling', '1993-01-01', 716299516, 'cstribbling19@qq.com', '2022-07-14'),
(47, 3, 'Lon', 'Filkov', '1979-06-05', 417842705, 'lfilkov1a@geocities.jp', '2024-09-28'),
(48, 1, 'Ronica', 'Cesconi', '1986-09-18', 13178331, 'rcesconi1b@nih.gov', '2023-05-31'),
(49, 14, 'Pooh', 'Kubat', '1995-05-30', 61213328, 'pkubat1c@rambler.ru', '2022-05-13'),
(50, 5, 'Fleming', 'Benech', '1978-12-27', 918775356, 'fbenech1d@infoseek.co.jp', '2023-03-17'),
(51, 5, 'Nolie', 'Scapelhorn', '1986-11-03', 516692600, 'nscapelhorn1e@sohu.com', '2023-06-09'),
(52, 9, 'Geri', 'Brealey', '1980-09-28', 252981033, 'gbrealey1f@infoseek.co.jp', '2021-08-07'),
(53, 12, 'Brynne', 'Hatchette', '1974-04-16', 8609931, 'bhatchette1g@cmu.edu', '2023-01-27'),
(54, 5, 'Shep', 'Winter', '2001-08-24', 219111418, 'swinter1h@live.com', '2021-07-16'),
(55, 11, 'Heall', 'Flamank', '1968-06-03', 242490524, 'hflamank1i@miibeian.gov.cn', '2022-04-29'),
(56, 1, 'Felike', 'Bavister', '1968-11-23', 400327427, 'fbavister1j@1und1.de', '2021-09-30'),
(57, 14, 'Sibylle', 'Keenor', '1983-05-10', 904155976, 'skeenor1k@joomla.org', '2022-02-09'),
(58, 10, 'Euphemia', 'Gwilliams', '1970-11-17', 743198801, 'egwilliams1l@nba.com', '2021-11-06'),
(59, 11, 'Willis', 'Wemyss', '1996-10-31', 6549000, 'wwemyss1m@answers.com', '2023-11-11'),
(60, 12, 'Micaela', 'Ledes', '1972-05-19', 4382268, 'mledes1n@google.pl', '2021-05-25'),
(61, 2, 'Violet', 'Hobben', '1999-10-20', 82944522, 'vhobben1o@yellowpages.com', '2022-09-26'),
(62, 14, 'Raynor', 'Pirrie', '1994-01-29', 132646893, 'rpirrie1p@apache.org', '2022-11-11'),
(63, 8, 'Yalonda', 'Webben', '1999-11-17', 162910901, 'ywebben1q@php.net', '2022-09-24'),
(64, 12, 'Jenilee', 'Kowalski', '1984-11-20', 26033980, 'jkowalski1r@deliciousdays.com', '2023-12-16'),
(65, 2, 'Nikolaos', 'Cotty', '1996-11-29', 66120201, 'ncotty1s@tripod.com', '2022-10-07'),
(66, 9, 'Tamarra', 'Doubrava', '1968-11-25', 62666612, 'tdoubrava1t@mapquest.com', '2024-02-23'),
(67, 5, 'Louisa', 'Niblo', '1966-07-26', 879827303, 'lniblo1u@bizjournals.com', '2023-03-07'),
(68, 5, 'Pru', 'Bonnefin', '1996-06-10', 403669735, 'pbonnefin1v@oracle.com', '2023-11-03'),
(69, 10, 'Natalina', 'Tatters', '1986-06-02', 774180676, 'ntatters1w@state.gov', '2023-12-15'),
(70, 8, 'Burtie', 'Straneo', '1973-06-02', 379001222, 'bstraneo1x@360.cn', '2023-11-06'),
(71, 9, 'Joyan', 'Atger', '1976-08-24', 220439722, 'jatger1y@google.com.hk', '2022-10-10'),
(72, 8, 'Corrie', 'Stoile', '1985-04-20', 681876495, 'cstoile1z@usda.gov', '2024-06-22'),
(73, 9, 'Joellyn', 'Mould', '1983-05-06', 2899927, 'jmould20@addtoany.com', '2021-10-14'),
(74, 3, 'Catlin', 'Le Gallo', '1977-04-04', 198526702, 'clegallo21@europa.eu', '2022-07-26'),
(75, 3, 'Neila', 'Turri', '2000-08-04', 88560211, 'nturri22@cnet.com', '2022-05-21'),
(76, 9, 'Leland', 'Rubinfeld', '1976-05-25', 106746372, 'lrubinfeld23@hexun.com', '2021-07-27'),
(77, 3, 'Caron', 'Tures', '1989-01-25', 220014884, 'ctures24@discuz.net', '2021-12-11'),
(78, 13, 'Ad', 'Birrell', '1993-07-22', 603785142, 'abirrell25@etsy.com', '2021-04-03'),
(79, 7, 'Kalie', 'Youel', '1991-09-06', 588281805, 'kyouel26@nature.com', '2024-09-30'),
(80, 1, 'Annie', 'Pennington', '1976-07-03', 104883953, 'apennington27@newyorker.com', '2023-09-01'),
(81, 8, 'Bard', 'Eblein', '1961-01-15', 773500899, 'beblein28@163.com', '2022-11-29'),
(82, 1, 'Tait', 'Brumpton', '2001-07-14', 28527333, 'tbrumpton29@bigcartel.com', '2024-05-29'),
(83, 3, 'Wolfy', 'Maryott', '1965-10-16', 543105257, 'wmaryott2a@theguardian.com', '2023-07-19'),
(84, 5, 'Ariadne', 'Woodburn', '2000-07-04', 989907789, 'awoodburn2b@who.int', '2024-04-02'),
(85, 14, 'Doti', 'Form', '1976-08-09', 789317799, 'dform2c@google.de', '2022-04-25'),
(86, 5, 'Frayda', 'Simister', '1970-05-06', 95161560, 'fsimister2d@flickr.com', '2022-01-26'),
(87, 10, 'Wilmette', 'Mayor', '1972-12-18', 520771795, 'wmayor2e@yelp.com', '2021-09-03'),
(88, 11, 'Glen', 'Delmage', '1961-09-24', 433324654, 'gdelmage2f@taobao.com', '2024-09-23'),
(89, 7, 'Xylina', 'Durward', '1975-07-06', 632091156, 'xdurward2g@vk.com', '2024-01-05'),
(90, 10, 'Jo ann', 'Robertet', '1967-10-28', 808155217, 'jrobertet2h@geocities.com', '2023-02-03'),
(91, 10, 'Maurita', 'Aleevy', '1969-10-31', 730857212, 'maleevy2i@sohu.com', '2021-07-22'),
(92, 6, 'Adams', 'Ipsley', '2001-11-30', 18786143, 'aipsley2j@nationalgeographic.c', '2022-11-19'),
(93, 10, 'Brandy', 'Jowsey', '1969-11-05', 598273045, 'bjowsey2k@seesaa.net', '2024-03-18'),
(94, 6, 'Ania', 'Tomes', '1993-07-02', 134998708, 'atomes2l@washington.edu', '2024-08-25'),
(95, 3, 'Marika', 'Sansum', '1986-10-08', 996287592, 'msansum2m@linkedin.com', '2022-08-17'),
(96, 7, 'Pauletta', 'Beckers', '1974-12-09', 817180659, 'pbeckers2n@answers.com', '2024-07-15'),
(99, 2, 'Ozzie', 'Jewsbury', '1990-02-27', 748331033, 'ojewsbury2q@drupal.org', '2022-09-09'),
(201, 2, 'Mateusz', 'Rożenek', '2005-10-08', 881641680, 'matroz@gmail.com', '2024-02-06'),
(202, 16, '5', '5', '2024-02-01', 54, '54@g.com', '2024-02-07'),
(203, 14, 'Miryng', 'Huan', '1975-03-04', 875698745, 'mhuan@gmail.com', '2024-02-06');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `osrodki`
--

CREATE TABLE `osrodki` (
  `id_osrodka` int(10) UNSIGNED NOT NULL,
  `nazwa` varchar(255) NOT NULL DEFAULT 'Brak nazwy',
  `data_dolaczenia` date NOT NULL,
  `ulica` varchar(255) NOT NULL DEFAULT 'Brak ulicy',
  `kod_pocztowy` varchar(255) NOT NULL,
  `miejscowosc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `osrodki`
--

INSERT INTO `osrodki` (`id_osrodka`, `nazwa`, `data_dolaczenia`, `ulica`, `kod_pocztowy`, `miejscowosc`) VALUES
(1, 'Gminny Ośrodek Pomocy Społecznej w Iwoniczu - Zdroju', '2023-06-12', 'Plac Detla 2', '38-440', 'Iwonicz-Zdrój'),
(2, 'Gminny Ośrodek Pomocy Społecznej w Chorkówce', '0000-00-00', 'Brak ulicy', '38-457', 'Chorkówka'),
(3, 'Miejski Ośrodek Pomocy Rodzinie w Krośnie', '0000-00-00', 'Piastowska 58', '38-400', 'Krosno'),
(4, 'Brak nazwy', '0000-00-00', 'Brak ulicy', 'lorem', 'Lorem ipsum'),
(5, 'Brak nazwy2', '0000-00-00', 'Brak ulicy', 'lorem', 'Lorem ipsum'),
(6, 'Brak nazwy3', '0000-00-00', 'Brak ulicy', 'lorem', 'Lorem ipsum'),
(7, 'Brak nazwy4', '2024-01-14', 'Brak ulicy', 'lorem', 'Lorem ipsum'),
(8, 'Brak nazwy5', '0000-00-00', 'Brak ulicy', 'lorem', 'Lorem ipsum'),
(10, 'Brak nazwy7', '0000-00-00', 'Brak ulicy', 'lorem', 'Lorem ipsum'),
(11, 'Brak nazwy8', '0000-00-00', 'Brak ulicy', 'lorem', 'Lorem ipsum'),
(12, 'Brak nazwy9', '2021-12-01', 'Brak ulicy', 'lorem', 'Lorem ipsum'),
(13, 'Brak nazwy10', '0000-00-00', 'Brak ulicy', 'lorem', 'Lorem ipsum'),
(14, 'Lorem Ipsum Lorem Ipsum', '0000-00-00', 'Brak ulicy', 'lorem', 'Lorem ipsum'),
(15, 'Osrodek nr 5', '2024-02-06', 'Kwietna', '25-889', 'Jarosław'),
(16, 'Osrodek nr 6', '2023-10-17', 'Polna', '25-889', 'Łąka'),
(18, 'Gminny Ośrodek Pomocy Społecznej w Rymanowie', '2024-01-01', 'Dworska 42', '38-480', 'Rymanów');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `platnosci`
--

CREATE TABLE `platnosci` (
  `id_platnosci` int(10) UNSIGNED NOT NULL,
  `id_czlonka` int(10) UNSIGNED NOT NULL,
  `tytul` text NOT NULL DEFAULT 'Płatnosc',
  `kwota` decimal(10,2) UNSIGNED NOT NULL,
  `data` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `platnosci`
--

INSERT INTO `platnosci` (`id_platnosci`, `id_czlonka`, `tytul`, `kwota`, `data`) VALUES
(1, 15, 'Opłata za zakupy', 98.00, '2024-01-12'),
(2, 69, 'Płatność za usługę', 199.00, '2024-01-12'),
(3, 37, 'Opłata za abonament', 514.00, '2024-01-12'),
(4, 89, 'Płatność za usługę', 461.00, '2024-01-12'),
(5, 64, 'Płatność za usługę', 800.00, '2024-01-12'),
(6, 98, 'Opłata za zakupy', 523.00, '2024-01-12'),
(7, 44, 'Opłata za zakupy', 794.00, '2024-01-12'),
(8, 7, 'Opłata za abonament', 156.00, '2024-01-12'),
(9, 8, 'Płatność za usługę', 23.00, '2024-01-12'),
(10, 18, 'Płatność za usługę', 848.00, '2024-01-12'),
(11, 10, 'Opłata za zakupy', 110.00, '2024-01-12'),
(12, 50, 'Płatność za usługę', 355.00, '2024-01-12'),
(13, 34, 'Opłata za zakupy', 402.00, '2024-01-12'),
(14, 30, 'Opłata za zakupy', 270.00, '2024-01-12'),
(15, 61, 'Płatność za usługę', 422.00, '2024-01-12'),
(16, 7, 'Przelew', 45.00, '2020-05-08');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wydarzenia`
--

CREATE TABLE `wydarzenia` (
  `data` date NOT NULL,
  `wydarzenie` varchar(255) NOT NULL,
  `uczestnicy` varchar(255) NOT NULL DEFAULT 'Brak zdefiniowanych uczestników'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `wydarzenia`
--

INSERT INTO `wydarzenia` (`data`, `wydarzenie`, `uczestnicy`) VALUES
('2023-06-26', 'Webinar', 'Anna Chobel'),
('2023-11-29', 'Symposium', 'Cały zarząd PZZPPS'),
('2023-12-17', 'Utworzenie tej tabeli', 'Anna Chobel, Sabina Rożenek'),
('2023-12-18', 'Utworzenie tej tabeli2', 'Sabina Rożenek'),
('2023-12-20', 'Utworzenie tej tabeli5', 'Cały zarząd PZZPPS'),
('2024-01-23', 'Utworzenie tej tabeli2', 'Brak zdefiniowanych uczestników'),
('2024-02-08', '32', '32'),
('2024-03-12', 'Workshop', 'Sabina Rożenek'),
('2024-05-27', 'bbbbbbbbbb', 'Cały zarząd PZZPPS'),
('2024-06-15', 'Workshop', 'Anna Uluszczak-Woźny'),
('2024-10-13', 'Seminar', 'Sabina Rożenek'),
('2024-10-21', 'Conference', 'Sabina Rożenek'),
('2024-11-21', 'Workshop', 'Anna Uluszczak-Woźny'),
('2025-02-01', 'Workshop', 'Cały zarząd PZZPPS'),
('2025-02-28', 'Webinar', 'Cały zarząd PZZPPS'),
('2025-10-20', 'Seminar', 'Anna Chobel, Anna Uluszczak-Woźny'),
('2025-10-30', 'Conference', 'Anna Uluszczak-Woźny');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zarzad`
--

CREATE TABLE `zarzad` (
  `id_osoby_zarzad` int(10) UNSIGNED NOT NULL,
  `id_osrodka` int(11) NOT NULL,
  `imie` varchar(20) NOT NULL,
  `nazwisko` varchar(30) NOT NULL,
  `telefon` int(9) NOT NULL,
  `email` varchar(30) NOT NULL,
  `stanowisko` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `zarzad`
--

INSERT INTO `zarzad` (`id_osoby_zarzad`, `id_osrodka`, `imie`, `nazwisko`, `telefon`, `email`, `stanowisko`) VALUES
(1, 5, 'Anna', 'Chobel', 111111111, 'achobel@email.com', 'Przewodnicząca związku'),
(2, 5, 'Anna', 'Uluszczak-Woźny', 111111110, 'aulwozny@email.com', 'Zastępca przewodniczącej związku'),
(3, 5, 'Małgorzata', 'Lachcik', 111111100, 'mlachcik@email.com', 'Zastępca przewodniczącej związku'),
(4, 5, 'Elżbieta', 'Wróbel', 111111000, 'ewrobel@gmail.com', 'Zastępca przewodniczącej związku'),
(5, 5, 'Sabina', 'Rożenek', 111110000, 'srozenek@gmail.com', 'Sekretarz związku'),
(6, 5, 'Monika', 'Trzyna', 111100000, 'mtrzyna@gmail.com', 'Skarbnik związku');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `_users`
--

CREATE TABLE `_users` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `_users`
--

INSERT INTO `_users` (`id`, `login`, `password`, `firstname`, `lastname`, `email`) VALUES
(1, 'admin', '@dmin1234', 'Admin', 'Adminowski', 'admin@gmail.com'),
(2, 'adam', 'adam1234', 'Adam', 'Nowak', 'a.nowak@gmail.com');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `czlonkowie`
--
ALTER TABLE `czlonkowie`
  ADD PRIMARY KEY (`id_czlonka`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indeksy dla tabeli `osrodki`
--
ALTER TABLE `osrodki`
  ADD PRIMARY KEY (`id_osrodka`),
  ADD UNIQUE KEY `nazwa` (`nazwa`);

--
-- Indeksy dla tabeli `platnosci`
--
ALTER TABLE `platnosci`
  ADD PRIMARY KEY (`id_platnosci`);

--
-- Indeksy dla tabeli `wydarzenia`
--
ALTER TABLE `wydarzenia`
  ADD PRIMARY KEY (`data`);

--
-- Indeksy dla tabeli `zarzad`
--
ALTER TABLE `zarzad`
  ADD PRIMARY KEY (`id_osoby_zarzad`);

--
-- Indeksy dla tabeli `_users`
--
ALTER TABLE `_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

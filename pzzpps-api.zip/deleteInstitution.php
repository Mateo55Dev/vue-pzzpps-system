<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $data = json_decode(file_get_contents("php://input"), true);

  $nazwa = htmlspecialchars($data['nazwa']);
  $data_dolaczenia = htmlspecialchars($data['data_dolaczenia']);
  $kod_pocztowy = htmlspecialchars($data['kod_pocztowy']);

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "pzzpps";

  $conn = new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $sql = "DELETE FROM osrodki WHERE nazwa = '$nazwa' AND data_dolaczenia = '$data_dolaczenia' AND kod_pocztowy = '$kod_pocztowy'";

  if ($conn->query($sql) === TRUE) {
    echo json_encode(array("success" => true, "message" => "Osrodek zostal usuniety pomyslnie."));
  } else {
    echo json_encode(array("success" => false, "message" => "Blad podczas usuwania osrodka: " . $conn->error));
  }

  $conn->close();
} else {
  echo json_encode(array("success" => false, "message" => "Metoda zadania nieprawidlowa."));
}
?>

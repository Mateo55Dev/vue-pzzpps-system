<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pzzpps";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id_platnosci, czlonkowie.id_czlonka, CONCAT(czlonkowie.imie, ' ', czlonkowie.nazwisko, ' (', czlonkowie.id_czlonka,')') AS 'nazwa', osrodki.nazwa AS 'nazwa_osr', tytul, kwota, DATE_FORMAT(data, '%d.%m.%Y') AS 'data' FROM platnosci 
INNER JOIN czlonkowie ON platnosci.id_czlonka = czlonkowie.id_czlonka 
INNER JOIN osrodki ON czlonkowie.id_osrodka = osrodki.id_osrodka;";
$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

$conn->close();

echo json_encode($data);
?>
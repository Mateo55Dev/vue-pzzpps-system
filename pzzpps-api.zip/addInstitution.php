<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// Sprawdzenie, czy żądanie było typu POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Dekodowanie danych JSON
    $data = json_decode(file_get_contents("php://input"), true);

    // Dane z formularza
    $nazwa = htmlspecialchars($data['nazwa']);
    $data_dolaczenia = htmlspecialchars($data['data_dolaczenia']);
    $ulica = htmlspecialchars($data['ulica']);
    $kod_pocztowy = htmlspecialchars($data['kod_pocztowy']);
    $miejscowosc = htmlspecialchars($data['miejscowosc']);

    // Połączenie z bazą danych
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pzzpps";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Sprawdzenie połączenia
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Zapytanie SQL do wstawienia nowego ośrodka
    $sql = "INSERT INTO osrodki (nazwa, data_dolaczenia, ulica, kod_pocztowy, miejscowosc) 
            VALUES ('$nazwa', '$data_dolaczenia', '$ulica', '$kod_pocztowy', '$miejscowosc')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(array("success" => true, "message" => "Nowy ośrodek został dodany pomyślnie."));
    } else {
        echo json_encode(array("success" => false, "message" => "Błąd podczas dodawania nowego ośrodka: " . $conn->error));
    }
    $conn->close();
} 
else {
    echo json_encode(array("success" => false, "message" => "Metoda żądania nieprawidłowa."));
    // Zamknięcie połączenia z bazą danych
   
}
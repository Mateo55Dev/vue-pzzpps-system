<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// Dane do połączenia z bazą danych MySQL
$host = "localhost";
$username_db = "root";
$password_db = "";
$database = "pzzpps";

$data = json_decode(file_get_contents("php://input"), true);

// Utwórz połączenie z bazą danych MySQL
$mysqli = new mysqli($host, $username_db, $password_db, $database);

// Sprawdź czy udało się połączyć z bazą danych
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Sprawdzanie poprawności danych logowania
$username = $mysqli->real_escape_string($data['username']);
$password = $mysqli->real_escape_string($data['password']);

// Haszowanie hasła
$hashed_password = password_hash($password, PASSWORD_BCRYPT);
//echo 'login: ', $username,' ';
//echo 'haslo: ',$hashed_password;

$query = "SELECT * FROM _users WHERE login = '$username' AND password = '$password'";
$result = $mysqli->query($query);

if ($result->num_rows > 0) {
    echo json_encode(['success' => true, 'message' => 'Login successful']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid username or password']);
}

// Zamknij połączenie z bazą danych
$mysqli->close();
?>

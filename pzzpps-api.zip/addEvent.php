<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// Sprawdzenie, czy żądanie było typu POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Dekodowanie danych JSON
    $data = json_decode(file_get_contents("php://input"), true);

    // Dane z formularza
    $dataWydarzenia = htmlspecialchars($data['data']);
    $nazwaWydarzenia = htmlspecialchars($data['wydarzenie']);
    $uczestnicy = htmlspecialchars($data['uczestnicy']);

    // Połączenie z bazą danych
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pzzpps";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Sprawdzenie połączenia
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Zapytanie SQL do wstawienia nowego wydarzenia
    $sql = "INSERT INTO wydarzenia (data, wydarzenie, uczestnicy) 
            VALUES ('$dataWydarzenia', '$nazwaWydarzenia', '$uczestnicy')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(array("success" => true, "message" => "Nowe wydarzenie zostało dodane pomyślnie."));
    } else {
        echo json_encode(array("success" => false, "message" => "Błąd podczas dodawania nowego wydarzenia: " . $conn->error));
    }

    // Zamknięcie połączenia z bazą danych
    $conn->close();
} else {
    echo json_encode(array("success" => false, "message" => "Metoda żądania nieprawidłowa."));
}
?>

<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// Sprawdzenie, czy żądanie było typu POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Dekodowanie danych JSON
    $data = json_decode(file_get_contents("php://input"), true);

    // Dane z formularza
    $imie = htmlspecialchars($data['imie']);
    $nazwisko = htmlspecialchars($data['nazwisko']);
    $data_urodzenia = htmlspecialchars($data['data_urodzenia']);
    $telefon = htmlspecialchars($data['telefon']);
    $email = htmlspecialchars($data['email']);
    $data_dolaczenia = htmlspecialchars($data['data_dolaczenia']);
    $osrodek = htmlspecialchars($data['osrodek']);

    // Połączenie z bazą danych
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pzzpps";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Sprawdzenie połączenia
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Zapytanie SQL do wstawienia nowego członka
    $sql = "INSERT INTO czlonkowie (imie, nazwisko, data_urodzenia, telefon, email, data_dolaczenia, id_osrodka) 
            VALUES ('$imie', '$nazwisko', '$data_urodzenia', '$telefon', '$email', '$data_dolaczenia', 
            (SELECT id_osrodka FROM osrodki WHERE nazwa = '$osrodek'))";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(array("success" => true, "message" => "Nowy członek został dodany pomyślnie."));
    } else {
        echo json_encode(array("success" => false, "message" => "Błąd podczas dodawania nowego członka: " . $conn->error));
    }

    // Zamknięcie połączenia z bazą danych
    $conn->close();
} else {
    echo json_encode(array("success" => false, "message" => "Metoda żądania nieprawidłowa."));
}
?>

<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// Sprawdzenie, czy żądanie było typu PUT
if ($_SERVER["REQUEST_METHOD"] == "PUT") {
    // Dekodowanie danych JSON
    $data = json_decode(file_get_contents("php://input"), true);

    // Dane z formularza
    $nazwa = htmlspecialchars($data['nazwa']);
    $data_dolaczenia = htmlspecialchars($data['data_dolaczenia']);
    $ulica = htmlspecialchars($data['ulica']);
    $kod_pocztowy = htmlspecialchars($data['kod_pocztowy']);
    $miejscowosc = htmlspecialchars($data['miejscowosc']);

    // Połączenie z bazą danych
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pzzpps";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Sprawdzenie połączenia
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Zapytanie SQL do aktualizacji ośrodka
    $sql = "UPDATE osrodki SET nazwa='$nazwa', data_dolaczenia='$data_dolaczenia', ulica='$ulica', kod_pocztowy='$kod_pocztowy', miejscowosc='$miejscowosc' WHERE id = ".$data['id'];

    if ($conn->query($sql) === TRUE) {
        echo json_encode(array("success" => true, "message" => "Ośrodek został zaktualizowany pomyślnie."));
    } else {
        echo json_encode(array("success" => false, "message" => "Błąd podczas aktualizacji ośrodka: " . $conn->error));
    }
    $conn->close();
} 
else {
    echo json_encode(array("success" => false, "message" => "Metoda żądania nieprawidłowa."));
}
?>

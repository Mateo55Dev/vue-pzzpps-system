<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// Rozpocznij sesję (jeśli jeszcze nie została rozpoczęta)
session_start();

// Zakończ sesję
session_destroy();

echo json_encode(['success' => true, 'message' => 'Logout successful']);
?>

<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pzzpps";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT czlonkowie.id_czlonka, CONCAT(czlonkowie.imie, ' ', czlonkowie.nazwisko, ' (',czlonkowie.id_czlonka,')') AS 'nazwa_czl', DATE_FORMAT(czlonkowie.data_urodzenia, '%d.%m.%Y') AS data_ur, telefon, email, DATE_FORMAT(czlonkowie.data_dolaczenia, '%d.%m.%Y') AS data_dol, osrodki.id_osrodka, osrodki.nazwa FROM czlonkowie 
INNER JOIN osrodki ON czlonkowie.id_osrodka = osrodki.id_osrodka;";
$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

$conn->close();

echo json_encode($data);
?>
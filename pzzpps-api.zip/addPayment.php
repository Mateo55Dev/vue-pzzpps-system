<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// Sprawdzenie, czy żądanie było typu POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Dekodowanie danych JSON
    $data = json_decode(file_get_contents("php://input"), true);

    // Dane z formularza
    $id_czlonka = htmlspecialchars($data['id_czlonka']);
    $tytul = htmlspecialchars($data['tytul']);
    $kwota = htmlspecialchars($data['kwota']);
    $data = htmlspecialchars($data['data']);

    // Połączenie z bazą danych
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pzzpps"; // Zmień na nazwę swojej bazy danych

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Sprawdzenie połączenia
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Zapytanie SQL do wstawienia nowej płatności
    $sql = "INSERT INTO platnosci (id_czlonka, tytul, kwota, data) 
            VALUES ('$id_czlonka', '$tytul', '$kwota', '$data')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(array("success" => true, "message" => "Nowa płatność została dodana pomyślnie."));
    } else {
        echo json_encode(array("success" => false, "message" => "Błąd podczas dodawania nowej płatności: " . $conn->error));
    }

    // Zamknięcie połączenia z bazą danych
    $conn->close();
} else {
    echo json_encode(array("success" => false, "message" => "Metoda żądania nieprawidłowa."));
}
?>

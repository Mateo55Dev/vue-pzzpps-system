Pliki php powinny znajdować się w folderze XAMPP: C:/xampp/htdocs/pzzpps-api/
Baza danych powinna nazywać się 'pzzpps'. 
Plik z bazą danych dołączony w folderze.
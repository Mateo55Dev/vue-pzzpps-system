<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pzzpps";

$conn = new mysqli($servername, $username, $password, $dbname);

// Sprawdź połączenie z bazą danych
if ($conn->connect_errno != 0) {
    echo "Error: " . $conn->connect_errno;
} else {
    // Pobierz wszystkie wydarzenia
    if ($result = @$conn->query("SELECT DATE_FORMAT(data, '%d %M %Y') AS data, wydarzenie, uczestnicy, (data-CURRENT_DATE()) AS pozostalo FROM wydarzenia")) {
        $events = [];

        // Przetwórz wynik zapytania do tablicy
        while ($row = $result->fetch_assoc()) {
            $events[] = $row;
        }

        echo json_encode($events);
        $result->free_result();
    }
}

$conn->close();
?>

<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// Sprawdzenie, czy żądanie było typu POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pobranie danych JSON z ciała żądania
    $data = json_decode(file_get_contents("php://input"), true);

    // Sprawdzenie, czy przekazano identyfikator ośrodka
    if (!isset($data['id'])) {
        echo json_encode(array("success" => false, "message" => "Nieprawidłowe żądanie. Brak identyfikatora ośrodka."));
        exit();
    }

    // Dekodowanie i walidacja identyfikatora ośrodka
    $id = htmlspecialchars($data['id']);
    if (!is_numeric($id) || $id <= 0) {
        echo json_encode(array("success" => false, "message" => "Nieprawidłowy identyfikator ośrodka."));
        exit();
    }

    // Połączenie z bazą danych
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pzzpps";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Sprawdzenie połączenia
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Zapytanie SQL do pobrania danych ośrodka
    $sql = "SELECT * FROM osrodki WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode(array("success" => true, "data" => $row));
    } else {
        echo json_encode(array("success" => false, "message" => "Ośrodek o podanym identyfikatorze nie istnieje."));
    }
    $conn->close();
} 
else {
    echo json_encode(array("success" => false, "message" => "Metoda żądania nieprawidłowa."));
}
?>

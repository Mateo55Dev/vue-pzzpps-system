<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = json_decode(file_get_contents("php://input"), true);

    $id = htmlspecialchars($data['id']);
    $imie = htmlspecialchars($data['imie']);
    $nazwisko = htmlspecialchars($data['nazwisko']);

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pzzpps";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "DELETE FROM czlonkowie WHERE imie = '$imie' AND nazwisko = '$nazwisko'";

    if ($conn->query($sql) == TRUE) {
        echo json_encode(array("success" => true, "message" => "Członek został usunięty pomyślnie."));
    } else {
        echo json_encode(array("success" => false, "message" => "Błąd podczas usuwania członka: " . $conn->error));
    }

    $conn->close();
} else {
    echo json_encode(array("success" => false, "message" => "Metoda żądania nieprawidłowa."));
}
?>

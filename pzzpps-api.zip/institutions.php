<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Połączenie z bazą danych
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pzzpps";

$conn = new mysqli($servername, $username, $password, $dbname);

// Sprawdzenie połączenia
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Zapytanie SQL do pobrania listy ośrodków
$sql = "SELECT id_osrodka, nazwa FROM osrodki";

// Wykonanie zapytania
$result = $conn->query($sql);

// Przetworzenie wyników zapytania na tablicę danych
$data = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Zamknięcie połączenia z bazą danych
$conn->close();

// Wyświetlenie danych jako JSON
echo json_encode($data);
?>
